import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';
import { getFirestore, doc, setDoc, getDoc, serverTimestamp, updateDoc, increment, collection, addDoc } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp({
  ...firebaseConfig,
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || firebaseConfig.apiKey
});

export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export async function signInWithGoogle() {
  const result = await signInWithPopup(auth, googleProvider);
  const user = result.user;
  
  // Check if user exists in Firestore
  const userRef = doc(db, 'users', user.uid);
  const userSnap = await getDoc(userRef);
  
  if (!userSnap.exists()) {
    // Create user profile
    await setDoc(userRef, {
      name: user.displayName || 'Anonymous',
      email: user.email || '',
      photoURL: user.photoURL || '',
      plan: 'free',
      createdAt: serverTimestamp(),
      postsGenerated: 0
    });
  }
  
  return user;
}

export async function incrementPostsGenerated(uid: string) {
  const userRef = doc(db, 'users', uid);
  await updateDoc(userRef, {
    postsGenerated: increment(1)
  });
}

export async function updatePlan(uid: string, plan: 'pro') {
  const userRef = doc(db, 'users', uid);
  await setDoc(userRef, { 
    plan, 
    planStarted: Date.now() 
  }, { merge: true });
}

export async function joinWaitlist(email: string, phone: string, userId: string) {
  return addDoc(collection(db, 'waitlist'), {
    email,
    phone,
    userId,
    createdAt: serverTimestamp()
  });
}

export function logOut() {
  return signOut(auth);
}
