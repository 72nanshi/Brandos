/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Mic2, 
  Calendar, 
  Target, 
  Settings, 
  Bell, 
  Plus, 
  Linkedin, 
  Instagram, 
  Twitter, 
  Edit3, 
  CheckCircle2, 
  ArrowUpRight,
  Flame,
  Users,
  Zap,
  TrendingUp,
  Cpu,
  Check,
  ChevronDown,
  Globe,
  PlusCircle,
  X,
  ArrowRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { generateBrandPost, generateBrandScore, generatePersonaKit } from '@/src/lib/groq';
import { auth, signInWithGoogle, logOut, db, updatePlan, incrementPostsGenerated, joinWaitlist } from '@/src/lib/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, onSnapshot } from 'firebase/firestore';
import { loadStripe } from '@stripe/stripe-js';

type Screen = 'dashboard' | 'voicestudio' | 'pricing' | 'brandscore' | 'personakit' | 'settings';
type Currency = 'INR' | 'USD';

interface UserData {
  plan: 'free' | 'pro';
  postsGenerated: number;
}

export default function App() {
  const [activeScreen, setActiveScreen] = useState<Screen>('dashboard');
  const [currency, setCurrency] = useState<Currency>('INR');
  const [user, setUser] = useState<User | null>(null);
  const [userData, setUserData] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(true);
  const [showPaywall, setShowPaywall] = useState(false);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (u) => {
      setUser(u);
      if (!u) {
        setUserData(null);
        setLoading(false);
      }
    });

    let unsubscribeDoc: (() => void) | undefined;
    if (user) {
      unsubscribeDoc = onSnapshot(doc(db, 'users', user.uid), (docSnap) => {
        if (docSnap.exists()) {
          setUserData(docSnap.data() as UserData);
        }
        setLoading(false);
      });
    }

    return () => {
      unsubscribeAuth();
      if (unsubscribeDoc) unsubscribeDoc();
    };
  }, [user]);

  if (loading) {
    return (
      <div className="h-screen bg-[#0F0F13] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-[#4F46E5]/30 border-t-[#4F46E5] rounded-full animate-spin" />
      </div>
    );
  }

  if (!user) {
    return <LoginView />;
  }

  const handleUpgradeStripe = () => {
    setActiveScreen('pricing');
    setShowPaywall(false);
  };

  const handleUpgradeRazorpay = () => {
    setActiveScreen('pricing');
    setShowPaywall(false);
  };

  return (
    <div className="flex h-screen bg-[#0F0F13] text-white font-sans selection:bg-[#4F46E5]/40 overflow-hidden">
      <AnimatePresence>
        {showPaywall && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-[#1A1A22] border border-white/5 rounded-[40px] p-10 max-w-xl w-full text-center space-y-8 relative shadow-2xl"
            >
              <button 
                onClick={() => setShowPaywall(false)}
                className="absolute top-6 right-6 text-gray-500 hover:text-white"
              >
                <X size={24} />
              </button>
              <div className="w-20 h-20 bg-[#4F46E5] rounded-[24px] flex items-center justify-center mx-auto shadow-xl shadow-[#4F46E5]/20">
                <Zap size={40} className="text-white" />
              </div>
              <div className="space-y-4">
                <h2 className="text-3xl font-black">Limit Reached.</h2>
                <p className="text-gray-400">You've generated 5 personal brand posts on the free plan. Join our exclusive waitlist for early access to Llama 3.3 Pro features.</p>
              </div>

              <button 
                onClick={handleUpgradeRazorpay}
                className="w-full py-6 rounded-3xl bg-[#4F46E5] text-white font-black text-lg hover:scale-[1.02] active:scale-[0.98] transition-all shadow-xl shadow-[#4F46E5]/20 flex items-center justify-center gap-3"
              >
                Join Waitlist
                <ArrowUpRight size={20} />
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      {/* Sidebar - 240px */}
      <aside className="w-[240px] bg-[#0F0F13] border-r border-white/5 flex flex-col shrink-0">
        <div className="p-8 text-center sm:text-left">
          <div className="flex items-center justify-center sm:justify-start gap-2 mb-10">
            <div className="w-8 h-8 bg-[#4F46E5] rounded-lg flex items-center justify-center shadow-lg shadow-[#4F46E5]/20">
              <Zap size={18} className="text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight">BrandOS</span>
          </div>

          <nav className="space-y-1">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={18} /> },
              { id: 'voicestudio', label: 'Voice Studio', icon: <Mic2 size={18} /> },
              { id: 'brandscore', label: 'BrandScore', icon: <Target size={18} /> },
              { id: 'personakit', label: 'PersonaKit', icon: <Users size={18} /> },
              { id: 'settings', label: 'Settings', icon: <Settings size={18} /> },
            ].map((item) => (
              <button
                key={item.id}
                //@ts-ignore
                onClick={() => setActiveScreen(item.id as Screen)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all text-sm font-medium ${
                  activeScreen === item.id 
                    ? 'bg-white/5 text-white' 
                    : 'text-gray-500 hover:text-gray-300 hover:bg-white/[0.02]'
                }`}
              >
                {item.icon}
                <span className="hidden sm:inline">{item.label}</span>
              </button>
            ))}
          </nav>

          <button 
            onClick={() => setActiveScreen('pricing')}
            className="w-full mt-6 bg-[#4F46E5]/10 text-[10px] font-bold text-[#4F46E5] uppercase tracking-widest py-2 rounded-lg hover:bg-[#4F46E5]/20 transition-colors hidden sm:block"
          >
            Upgrade Plan
          </button>
        </div>

        <div className="mt-auto p-8 border-t border-white/5 hidden sm:block">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#4F46E5] to-[#EC4899] p-[2px]">
                <div className="w-full h-full rounded-full bg-[#0F0F13] flex items-center justify-center overflow-hidden">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt={user.displayName || ''} className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-xs font-bold">{(user.displayName || user.email || 'U').substring(0, 2).toUpperCase()}</span>
                  )}
                </div>
              </div>
              <div className="absolute -bottom-1 -right-1 bg-emerald-500 w-3 h-3 rounded-full border-2 border-[#0F0F13]" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold truncate">{user.displayName || 'Creator'}</p>
              <span className="inline-block px-1.5 py-0.5 rounded bg-[#4F46E5]/10 text-[10px] text-[#4F46E5] font-bold uppercase tracking-wider">
                {userData?.plan === 'pro' ? 'Pro Plan' : 'Free Plan'}
              </span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative overflow-hidden">
        <header className="h-20 border-b border-white/5 flex items-center justify-between px-8 bg-[#0F0F13]/80 backdrop-blur-md z-10">
          <h1 className="text-xl font-bold tracking-tight capitalize">
            {activeScreen === 'dashboard' ? 'Dashboard' : 
             activeScreen === 'voicestudio' ? 'Voice Studio' : 
             activeScreen === 'brandscore' ? 'BrandScore Analysis' :
             activeScreen === 'personakit' ? 'PersonaKit Builder' :
             activeScreen === 'settings' ? 'Settings' :
             'Plan Selection'}
          </h1>
          <div className="flex items-center gap-4">
            {activeScreen === 'pricing' && (
              <div className="flex items-center bg-white/5 rounded-full p-1 mr-2 invisible">
                <button 
                  onClick={() => setCurrency('INR')}
                  className={`px-4 py-1 rounded-full text-[10px] font-bold transition-all ${currency === 'INR' ? 'bg-[#4F46E5] text-white' : 'text-gray-500'}`}
                >
                  INR
                </button>
                <button 
                  onClick={() => setCurrency('USD')}
                  className={`px-4 py-1 rounded-full text-[10px] font-bold transition-all ${currency === 'USD' ? 'bg-[#4F46E5] text-white' : 'text-gray-500'}`}
                >
                  USD
                </button>
              </div>
            )}
            <button className="p-2.5 rounded-xl hover:bg-white/5 transition-colors text-gray-500 hover:text-white">
              <Bell size={20} />
            </button>
            <button className="px-5 py-2.5 bg-[#4F46E5] text-white rounded-xl text-sm font-bold shadow-lg shadow-[#4F46E5]/30 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2">
              <Plus size={18} />
              <span className="hidden sm:inline">Create Post</span>
            </button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
          <AnimatePresence mode="wait">
            {activeScreen === 'dashboard' && <DashboardView />}
            {activeScreen === 'voicestudio' && <VoiceStudioView userData={userData} onLimitReached={() => setShowPaywall(true)} />}
            {activeScreen === 'brandscore' && <BrandScoreView />}
            {activeScreen === 'personakit' && <PersonaKitView />}
            {activeScreen === 'settings' && <SettingsView />}
            {activeScreen === 'pricing' && <PricingView />}
          </AnimatePresence>
        </div>
      </main>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.05); border-radius: 2px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.1); }
      `}</style>
    </div>
  );
}

function DashboardView() {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      className="grid grid-cols-12 gap-8 max-w-7xl mx-auto w-full"
    >
      {/* Left Column: Today's Queue */}
      <div className="col-span-12 lg:col-span-8 space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-gray-500 uppercase tracking-widest">Today's Queue</h2>
          <button className="text-xs text-[#4F46E5] font-bold hover:underline">View All Schedule</button>
        </div>
        
        <div className="space-y-4">
          {[
            { platform: 'LinkedIn', icon: <Linkedin size={16} />, text: "3 lessons from scaling my SaaS to $10k MRR without outside funding...", status: 'Scheduled', time: '2:15 PM' },
            { platform: 'Twitter', icon: <Twitter size={16} />, text: "Build in public is dead. Learn in public is the new alpha.", status: 'Draft', time: '4:30 PM' },
            { platform: 'Instagram', icon: <Instagram size={16} />, text: "A snapshot into our culture: Why we don't do standups anymore.", status: 'Scheduled', time: 'Tomorrow' },
          ].map((post, i) => (
            <div key={i} className="bg-white/[0.03] border border-white/5 rounded-2xl p-5 hover:bg-white/[0.05] transition-all group">
              <div className="flex gap-5">
                <div className="w-12 h-12 rounded-xl bg-white/[0.05] flex items-center justify-center text-gray-400 group-hover:text-white transition-colors">
                  {post.icon}
                </div>
                <div className="flex-1 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-gray-500">{post.platform} • {post.time}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                      post.status === 'Scheduled' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-amber-500/10 text-amber-500'
                    }`}>
                      {post.status}
                    </span>
                  </div>
                  <p className="text-sm text-gray-300 leading-relaxed font-medium">"{post.text}"</p>
                  <div className="flex gap-2 pt-2">
                    <button className="px-3 py-1.5 rounded-lg bg-white/5 border border-white/5 text-xs font-bold text-gray-400 hover:text-white hover:bg-white/10 transition-all flex items-center gap-1.5">
                      <Edit3 size={14} />
                      Edit
                    </button>
                    <button className="px-3 py-1.5 rounded-lg bg-[#4F46E5]/10 border border-[#4F46E5]/20 text-xs font-bold text-[#4F46E5] hover:bg-[#4F46E5]/20 transition-all flex items-center gap-1.5">
                      <CheckCircle2 size={14} />
                      Approve
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Section: Voice Profile */}
        <div className="pt-8">
          <div className="bg-[#4F46E5]/5 border border-[#4F46E5]/10 rounded-2xl p-6 relative overflow-hidden">
            <div className="absolute right-0 top-0 w-32 h-32 bg-[#4F46E5] blur-[80px] opacity-20 pointer-events-none" />
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-bold">Voice Profile Strength</h3>
                <p className="text-xs text-gray-400">Personal branding consistency analysis</p>
              </div>
              <span className="text-2xl font-black text-[#4F46E5]">94%</span>
            </div>
            <div className="w-full bg-white/5 rounded-full h-2">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: "94%" }}
                transition={{ duration: 1.5, ease: "easeOut" }}
                className="h-full bg-[#4F46E5] rounded-full relative"
              >
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-white shadow-[0_0_15px_rgba(79,70,229,0.5)] border-2 border-[#4F46E5]" />
              </motion.div>
            </div>
            <div className="flex gap-4 mt-6">
              <div className="px-3 py-1.5 rounded-lg bg-white/5 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Aesthetic: Minimalist</div>
              <div className="px-3 py-1.5 rounded-lg bg-white/5 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Tone: Authoritative</div>
              <div className="px-3 py-1.5 rounded-lg bg-white/5 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Niche: B2B SaaS</div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Column: Stats */}
      <div className="col-span-12 lg:col-span-4 space-y-6">
        <h2 className="text-sm font-bold text-gray-500 uppercase tracking-widest">Performance Insights</h2>
        
        <div className="grid grid-cols-1 gap-4">
          {[
            { label: 'Posting Streak', value: '14 days', icon: <Flame className="text-orange-500" />, sub: 'Top 5% of creators' },
            { label: 'Posts This Month', value: '47', icon: <Zap className="text-yellow-500" />, sub: '+12 from last month' },
            { label: 'Profile Visits', value: '+23%', icon: <TrendingUp className="text-emerald-500" />, sub: 'Organic growth up' },
            { label: 'Leads Generated', value: '8', icon: <Users className="text-[#4F46E5]" />, sub: 'High intent qualified' },
          ].map((stat, i) => (
            <div key={i} className="bg-white/[0.02] border border-white/5 rounded-2xl p-5 hover:border-white/10 transition-colors">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-white/[0.03] flex items-center justify-center">
                  {stat.icon}
                </div>
                <div>
                  <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-0.5">{stat.label}</p>
                  <p className="text-xl font-bold">{stat.value}</p>
                  <p className="text-[10px] text-gray-600 font-medium mt-1">{stat.sub}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-[#121214] rounded-2xl p-6 border border-white/5">
          <h3 className="text-sm font-bold mb-4 flex items-center gap-2">
            <Globe size={16} className="text-[#4F46E5]" />
            Audience Distribution
          </h3>
          <div className="space-y-4">
            {[
              { label: 'United States', value: '42%', color: 'bg-[#4F46E5]' },
              { label: 'India', value: '28%', color: 'bg-[#EC4899]' },
              { label: 'United Kingdom', value: '15%', color: 'bg-emerald-500' },
            ].map((country, i) => (
              <div key={i} className="space-y-1.5">
                <div className="flex justify-between text-[10px] font-bold text-gray-500 uppercase">
                  <span>{country.label}</span>
                  <span>{country.value}</span>
                </div>
                <div className="w-full bg-white/5 h-1 rounded-full overflow-hidden">
                  <div className={`h-full ${country.color}`} style={{ width: country.value }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function VoiceStudioView({ userData, onLimitReached }: { userData: UserData | null, onLimitReached: () => void }) {
  const [idea, setIdea] = useState('');
  const [samples, setSamples] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [variants, setVariants] = useState<string[]>([]);
  const [selectedPlatform, setSelectedPlatform] = useState('LinkedIn');
  const [selectedTone, setSelectedTone] = useState('Professional');

  const generate = async () => {
    if (!idea.trim()) return;
    
    // Paywall Check
    if (userData?.plan === 'free' && (userData?.postsGenerated || 0) >= 5) {
      onLimitReached();
      return;
    }

    setIsGenerating(true);
    try {
      const posts = await generateBrandPost(samples, idea, selectedTone, selectedPlatform);
      setVariants(posts);
      
      // Increment counter in Firestore
      if (auth.currentUser) {
        await incrementPostsGenerated(auth.currentUser.uid);
      }
    } catch (e) {
      console.error(e);
      alert('Failed to generate variants. Check console for details.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="grid grid-cols-12 gap-10 max-w-7xl mx-auto w-full h-full"
    >
      {/* Left Panel: Inputs */}
      <div className="col-span-12 lg:col-span-5 space-y-8 pb-20">
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest flex items-center gap-2">
              <PlusCircle size={12} />
              Writing Samples (Ghostwriter Mode)
            </label>
            <textarea 
              value={samples}
              onChange={(e) => setSamples(e.target.value)}
              placeholder="Paste 1-2 examples of your previous posts here to match your unique brand voice..."
              className="w-full h-32 bg-white/[0.02] border border-white/5 rounded-2xl p-4 text-xs text-gray-400 resize-none focus:outline-none focus:border-[#4F46E5] transition-all placeholder:text-gray-700 leading-relaxed"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Post Conceptualizer</label>
            <div className="relative group">
              <textarea 
                value={idea}
                onChange={(e) => setIdea(e.target.value)}
                placeholder="Drop your raw thoughts or core idea here..."
                className="w-full h-48 bg-white/[0.02] border border-white/5 rounded-2xl p-6 text-sm text-gray-300 resize-none focus:outline-none focus:border-[#4F46E5] transition-all placeholder:text-gray-600 leading-relaxed"
              />
              <div className="absolute bottom-4 right-4 flex gap-2">
                <button className="p-2.5 rounded-xl bg-white/5 text-gray-500 hover:text-white transition-colors">
                  <Mic2 size={18} />
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="space-y-3">
            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Brand Voice Tone</label>
            <div className="flex flex-wrap gap-2">
              {['Professional', 'Bold', 'Story', 'Casual', 'Witty'].map(tone => (
                <button 
                  key={tone}
                  onClick={() => setSelectedTone(tone)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                    selectedTone === tone ? 'bg-[#4F46E5] text-white' : 'bg-white/5 text-gray-500 hover:text-gray-300'
                  }`}
                >
                  {tone}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Target Channel</label>
            <div className="grid grid-cols-3 gap-3">
              {[
                { id: 'LinkedIn', icon: <Linkedin size={16} /> },
                { id: 'Twitter', icon: <Twitter size={16} /> },
                { id: 'Instagram', icon: <Instagram size={16} /> },
              ].map(platform => (
                <button 
                  key={platform.id}
                  onClick={() => setSelectedPlatform(platform.id)}
                  className={`flex items-center justify-center gap-2 px-4 py-3 rounded-xl border transition-all ${
                    selectedPlatform === platform.id 
                      ? 'bg-[#4F46E5]/10 border-[#4F46E5] text-white font-bold' 
                      : 'bg-white/5 border-transparent text-gray-500 hover:border-white/10'
                  }`}
                >
                  {platform.icon}
                  <span className="text-xs">{platform.id}</span>
                </button>
              ))}
            </div>
          </div>

          <button 
            onClick={generate}
            disabled={isGenerating || !idea.trim()}
            className="w-full py-4 bg-white text-black font-black rounded-2xl flex items-center justify-center gap-3 hover:bg-gray-200 transition-all shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isGenerating ? (
              <div className="w-5 h-5 border-3 border-black/30 border-t-black rounded-full animate-spin" />
            ) : (
              <>
                <Cpu size={20} />
                Generate Variants
              </>
            )}
          </button>
        </div>
      </div>

      {/* Right Panel: Variants */}
      <div className="col-span-12 lg:col-span-7 space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Generated Variants</h2>
          <span className="text-[10px] font-bold text-[#4F46E5] uppercase tracking-widest">3 Versions Ready</span>
        </div>

        <div className="space-y-4">
          <AnimatePresence>
            {variants.length > 0 ? variants.map((v, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-white/[0.03] border border-white/5 rounded-2xl p-6 hover:border-[#4F46E5]/30 transition-all group"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-lg bg-emerald-500/10 text-emerald-500 flex items-center justify-center text-[10px] font-bold">
                      0{i+1}
                    </span>
                    <span className={`text-[10px] font-bold uppercase tracking-widest ${
                      i === 0 ? 'text-emerald-500' : i === 1 ? 'text-blue-500' : 'text-purple-500'
                    }`}>
                      {i === 0 ? 'Narrative Hook' : i === 1 ? 'Punchy / Direct' : 'Philosophical'}
                    </span>
                  </div>
                  <button className="text-gray-500 hover:text-white transition-colors">
                    <ArrowUpRight size={14} />
                  </button>
                </div>
                <p className="text-sm text-gray-300 leading-relax font-medium">{v}</p>
                <div className="flex items-center justify-between mt-4">
                  <span className="text-[10px] font-bold text-gray-600 uppercase tracking-widest">{v.length} Characters</span>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => {
                        navigator.clipboard.writeText(v);
                        alert('Copied to clipboard!');
                      }}
                      className="px-3 py-1.5 rounded-lg bg-white/5 text-[10px] font-bold text-gray-400 hover:text-white transition-all uppercase tracking-widest"
                    >
                      Copy
                    </button>
                    <button className="px-3 py-1.5 rounded-lg bg-[#4F46E5] text-white text-[10px] font-bold hover:bg-[#4338CA] transition-all uppercase tracking-widest shadow-lg shadow-[#4F46E5]/20">
                      Schedule
                    </button>
                  </div>
                </div>
              </motion.div>
            )) : !isGenerating && (
              <div className="h-[400px] rounded-2xl border-2 border-dashed border-white/5 flex flex-col items-center justify-center text-gray-600 gap-4">
                <div className="p-4 rounded-full bg-white/5">
                  <Mic2 size={32} />
                </div>
                <p className="text-sm font-medium">Your generated variants will appear here</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
}

function PricingView() {
  const [phone, setPhone] = useState('');
  const [isJoining, setIsJoining] = useState(false);
  const [joined, setJoined] = useState(false);

  const handleJoin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser?.email) return;
    setIsJoining(true);
    try {
      await joinWaitlist(auth.currentUser.email, phone, auth.currentUser.uid);
      setJoined(true);
    } catch (e) {
      console.error(e);
      alert('Failed to join waitlist. Please try again.');
    } finally {
      setIsJoining(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.98 }}
      className="max-w-xl mx-auto w-full pt-10"
    >
      <div className="bg-white/[0.02] border border-white/5 rounded-[40px] p-12 text-center space-y-8 shadow-2xl">
        <div className="w-20 h-20 bg-[#4F46E5]/10 text-[#4F46E5] rounded-[24px] flex items-center justify-center mx-auto mb-4">
          <Zap size={40} />
        </div>
        
        {joined ? (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <h2 className="text-3xl font-black">You're in!</h2>
            <p className="text-gray-400">We've added you to our exclusive early-access waitlist. We'll notify you as soon as the Pro features launch.</p>
            <div className="pt-6">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-500/10 text-emerald-500 rounded-full text-xs font-bold uppercase tracking-widest">
                <Check size={14} />
                Request Received
              </div>
            </div>
          </motion.div>
        ) : (
          <>
            <div className="space-y-4">
              <h2 className="text-4xl font-black tracking-tight">Access Pro Features.</h2>
              <p className="text-gray-500">We're currently scaling our infrastructure for Llama 3.3. Join the waitlist to get priority access when we go live.</p>
            </div>

            <form onSubmit={handleJoin} className="space-y-4 pt-4 text-left">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-2">Email Address</label>
                <input 
                  type="email" 
                  value={auth.currentUser?.email || ''} 
                  disabled
                  className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-sm text-gray-400 cursor-not-allowed"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest ml-2">WhatsApp / Phone (Optional)</label>
                <input 
                  type="tel" 
                  placeholder="+1 (555) 000-0000"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full bg-white/[0.02] border border-white/10 rounded-2xl p-4 text-sm focus:outline-none focus:border-[#4F46E5] transition-all"
                />
              </div>
              <button 
                type="submit"
                disabled={isJoining}
                className="w-full py-5 bg-[#4F46E5] text-white font-black rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-xl shadow-[#4F46E5]/20 flex items-center justify-center gap-3"
              >
                {isJoining ? (
                  <div className="w-5 h-5 border-3 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    Join Waitlist
                    <ArrowRight size={18} />
                  </>
                )}
              </button>
            </form>
          </>
        )}
      </div>

      <div className="mt-12 text-center opacity-40">
        <p className="text-[10px] font-bold uppercase tracking-widest">Free plan remains active</p>
      </div>
    </motion.div>
  );
}

function BrandScoreView() {
  const [scoreData, setScoreData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchScore = async () => {
      setLoading(true);
      try {
        const storedPosts = JSON.parse(localStorage.getItem('user_posts') || '[]');
        // Fallback mock posts if none in storage
        const postsToAnalyze = storedPosts.length > 0 ? storedPosts : [
          "I help founders build systems that scale. I believe in execution over perfection.",
          "Building in public is the ultimate cheat code for hiring.",
          "Consistency is boring, but it's the only way to win."
        ];
        const data = await generateBrandScore(postsToAnalyze);
        setScoreData(data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchScore();
  }, []);

  if (loading) return (
    <div className="h-[60vh] flex flex-col items-center justify-center gap-4">
      <div className="w-12 h-12 border-4 border-[#4F46E5]/30 border-t-[#4F46E5] rounded-full animate-spin" />
      <p className="text-sm font-bold text-gray-500 uppercase tracking-widest animate-pulse">Analyzing Brand Pulse...</p>
    </div>
  );

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto space-y-10"
    >
      <div className="flex flex-col items-center justify-center text-center space-y-6">
        <div className="relative w-48 h-48">
          <svg className="w-full h-full transform -rotate-90">
            <circle cx="96" cy="96" r="88" fill="none" stroke="currentColor" strokeWidth="12" className="text-white/5" />
            <motion.circle 
              cx="96" cy="96" r="88" fill="none" stroke="currentColor" strokeWidth="12" strokeDasharray={552.92}
              initial={{ strokeDashoffset: 552.92 }}
              animate={{ strokeDashoffset: 552.92 - (552.92 * scoreData.overallScore) / 100 }}
              transition={{ duration: 1.5, ease: "easeOut" }}
              className="text-[#4F46E5]" 
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-6xl font-black">{scoreData.overallScore}</span>
            <span className="text-xs font-bold text-gray-500 uppercase tracking-widest">Brand Score</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Consistency', value: scoreData.consistency, color: 'text-emerald-500' },
          { label: 'Hook Strength', value: scoreData.hookStrength, color: 'text-blue-500' },
          { label: 'Engagement', value: scoreData.engagementPotential, color: 'text-purple-500' },
          { label: 'Clarity', value: 88, color: 'text-orange-500' },
        ].map((m, i) => (
          <div key={i} className="bg-white/[0.02] border border-white/5 rounded-2xl p-6 text-center space-y-2">
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">{m.label}</p>
            <p className={`text-2xl font-black ${m.color}`}>{m.value}%</p>
          </div>
        ))}
      </div>

      <div className="bg-[#4F46E5]/10 border border-[#4F46E5]/30 rounded-3xl p-8 space-y-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-[#4F46E5]/20 text-[#4F46E5]">
            <Cpu size={20} />
          </div>
          <h3 className="text-sm font-bold uppercase tracking-widest">Strategic Insight</h3>
        </div>
        <p className="text-gray-300 leading-relaxed font-medium">"{scoreData.insight}"</p>
      </div>
    </motion.div>
  );
}

function SettingsView() {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-2xl mx-auto space-y-8"
    >
      <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-8 space-y-6">
        <h2 className="text-xl font-bold">Account Settings</h2>
        <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-[#4F46E5] flex items-center justify-center font-bold">
              {auth.currentUser?.email?.substring(0, 1).toUpperCase()}
            </div>
            <div>
              <p className="font-bold">{auth.currentUser?.displayName || 'Social Creator'}</p>
              <p className="text-xs text-gray-500">{auth.currentUser?.email}</p>
            </div>
          </div>
          <button 
            onClick={() => logOut()}
            className="px-4 py-2 bg-red-500/10 text-red-500 text-xs font-bold rounded-xl hover:bg-red-500/20 transition-all uppercase tracking-widest"
          >
            Log Out
          </button>
        </div>
      </div>

      <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-8">
        <h3 className="text-sm font-bold uppercase tracking-widest text-gray-500 mb-6">Preferences</h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm">Email Notifications</span>
            <div className="w-10 h-5 bg-[#4F46E5] rounded-full flex items-center px-1">
              <div className="w-3 h-3 bg-white rounded-full translate-x-5" />
            </div>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm">Dark Mode</span>
            <div className="w-10 h-5 bg-[#4F46E5] rounded-full flex items-center px-1">
              <div className="w-3 h-3 bg-white rounded-full translate-x-5" />
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function PersonaKitView() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<any>({
    problem: '', expertise: '', audience: '', tone: '', ambition: ''
  });
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const questions = [
    { key: 'problem', q: "What's the main problem you solve?", p: "e.g., Scaling operations for SaaS founders..." },
    { key: 'expertise', q: "What's your unique 'secret sauce'?", p: "e.g., 10 years in backend architecture..." },
    { key: 'audience', q: "Who is your dream client/reader?", p: "e.g., Series A CTOs who need speed..." },
    { key: 'tone', q: "How should your writing feel?", p: "e.g., Ruthlessly efficient and technical..." },
    { key: 'ambition', q: "Where do you want to be in 12 months?", p: "e.g., Thought leader in AI ethics..." },
  ];

  const next = async () => {
    if (step < questions.length - 1) {
      setStep(step + 1);
    } else {
      setLoading(true);
      try {
        const data = await generatePersonaKit(answers);
        setResult(data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
  };

  if (loading) return (
    <div className="h-[60vh] flex flex-col items-center justify-center gap-4 text-center">
      <div className="w-16 h-16 relative">
        <div className="absolute inset-0 bg-[#4F46E5]/20 rounded-full animate-ping" />
        <div className="relative w-full h-full bg-[#4F46E5] rounded-full flex items-center justify-center text-white">
          <Users size={32} />
        </div>
      </div>
      <div className="space-y-1">
        <h3 className="text-lg font-bold">Forging Your Identity</h3>
        <p className="text-sm text-gray-500">Llama 3.3 is mapping your content pillars...</p>
      </div>
    </div>
  );

  if (result) return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="max-w-5xl mx-auto space-y-10 pb-20"
    >
      <div className="grid grid-cols-12 gap-8">
        <div className="col-span-12 lg:col-span-4 space-y-6">
          <div className="bg-[#4F46E5] rounded-3xl p-8 text-white space-y-6">
            <div className="space-y-1">
              <p className="text-[10px] font-bold uppercase tracking-widest opacity-60">Your Niche</p>
              <h2 className="text-2xl font-black">{result.niche}</h2>
            </div>
            <div className="space-y-1">
              <p className="text-[10px] font-bold uppercase tracking-widest opacity-60">High-Status Positioning</p>
              <p className="text-sm font-medium leading-relaxed">{result.positioning}</p>
            </div>
          </div>

          <div className="bg-white/[0.02] border border-white/5 rounded-3xl p-8 space-y-6">
            <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Bio Variants</h3>
            {Object.entries(result.bioVariants || {}).map(([key, bio]: [string, any]) => (
              <div key={key} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-[#4F46E5] uppercase">{key}</span>
                  <button 
                    onClick={() => {
                        navigator.clipboard.writeText(bio);
                        alert('Bio copied!');
                    }}
                    className="text-[10px] font-bold text-gray-500 hover:text-white uppercase transition-colors"
                  >
                    Copy
                  </button>
                </div>
                <p className="text-xs text-gray-400 bg-white/[0.02] p-3 rounded-xl border border-white/5">{bio}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="col-span-12 lg:col-span-8 space-y-10">
          <div className="space-y-4">
            <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Content Pillars</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {(result.contentPillars || []).map((p: string, i: number) => (
                <div key={i} className="bg-white/[0.02] border border-white/5 rounded-2xl p-5 hover:border-[#4F46E5]/30 transition-all">
                  <span className="text-[10px] font-bold text-[#4F46E5] mb-2 block">Pillar 0{i+1}</span>
                  <p className="text-sm font-bold">{p}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Top 10 Viral Topics</h3>
            <div className="grid grid-cols-1 gap-2">
              {(result.postTopics || []).map((topic: string, i: number) => (
                <div key={topic} className="bg-white/[0.02] p-4 rounded-xl border border-white/5 text-sm text-gray-300 flex items-center gap-4">
                  <span className="text-gray-600 font-mono text-xs">{String(i+1).padStart(2, '0')}.</span>
                  {topic}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );

  const currentQ = questions[step];

  return (
    <div className="max-w-2xl mx-auto h-[60vh] flex flex-col items-center justify-center">
      <div className="w-full space-y-8">
        <div className="space-y-4 text-center">
          <span className="px-3 py-1 bg-[#4F46E5]/10 text-[#4F46E5] rounded-full text-[10px] font-bold uppercase tracking-widest">
            Step {step + 1} of {questions.length}
          </span>
          <h2 className="text-3xl font-black tracking-tight">{currentQ.q}</h2>
        </div>

        <textarea 
          value={answers[currentQ.key]}
          onChange={(e) => setAnswers({...answers, [currentQ.key]: e.target.value})}
          placeholder={currentQ.p}
          className="w-full h-32 bg-white/[0.02] border border-white/10 rounded-3xl p-8 text-lg focus:outline-none focus:border-[#4F46E5] transition-all resize-none placeholder:text-gray-700"
        />

        <div className="flex gap-4">
          {step > 0 && (
            <button 
              onClick={() => setStep(step - 1)}
              className="flex-1 py-4 bg-white/5 text-white font-bold rounded-2xl hover:bg-white/10 transition-all"
            >
              Back
            </button>
          )}
          <button 
            onClick={next}
            disabled={!answers[currentQ.key].trim()}
            className="flex-1 py-4 bg-[#4F46E5] text-white font-black rounded-2xl hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50"
          >
            {step === questions.length - 1 ? 'Generate Kit' : 'Continue'}
          </button>
        </div>
      </div>
    </div>
  );
}

function LoginView() {
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const handleLogin = async () => {
    setIsLoggingIn(true);
    try {
      await signInWithGoogle();
    } catch (e) {
      console.error(e);
      alert('Login failed. Please try again.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  return (
    <div className="h-screen bg-[#0F0F13] text-white flex flex-col items-center justify-center p-8 text-center space-y-10">
      <div className="space-y-4">
        <div className="w-16 h-16 bg-[#4F46E5] rounded-2xl mx-auto flex items-center justify-center shadow-2xl shadow-[#4F46E5]/40 mb-8">
          <Zap size={32} />
        </div>
        <h1 className="text-5xl font-black tracking-tight bg-gradient-to-tr from-white to-gray-500 bg-clip-text text-transparent">
          The Operating System<br />for Personal Brands.
        </h1>
        <p className="text-gray-500 max-w-md mx-auto text-lg">
          Master your voice, scale your influence, and automate your presence with Llama 3.3.
        </p>
      </div>

      <button 
        onClick={handleLogin}
        disabled={isLoggingIn}
        className="group relative px-8 py-4 bg-white text-black font-black rounded-2xl hover:scale-[1.05] active:scale-[0.98] transition-all flex items-center gap-4 shadow-xl disabled:opacity-50"
      >
        {isLoggingIn ? (
           <div className="w-5 h-5 border-3 border-black/30 border-t-black rounded-full animate-spin" />
        ) : (
          <>
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-5 h-5" />
            Continue with Google
          </>
        )}
      </button>

      <p className="text-[10px] text-gray-700 font-bold uppercase tracking-widest">
        No credit card required. Free forever (limited).
      </p>
    </div>
  );
}


