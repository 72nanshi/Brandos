import express from 'express';
import { GoogleGenAI } from "@google/genai";
import Groq from 'groq-sdk';
import { initializeApp, cert } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.VITE_DEV === 'true' ? 3001 : 3000;

app.use(express.json());

// Serve static files from the Vite build directory
app.use(express.static(path.join(__dirname, 'dist')));

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

const groq = new Groq({
  apiKey: process.env.GROQ_API_KEY,
});

// Proxy endpoint for Gemini Chat
app.post('/api/chat', async (req, res) => {
  try {
    const { message, history } = req.body;
    
    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    const chat = ai.chats.create({
      model: "gemini-3-flash-preview",
      config: {
        systemInstruction: "You are Aether, a sophisticated and helpful AI assistant. You provide concise, accurate, and insightful information. Your tone is professional yet warm. You use markdown for formatting when appropriate.",
      },
      history: history || []
    });

    const result = await chat.sendMessage({ message });
    res.json({ text: result.text });
  } catch (error: any) {
    console.error('Gemini API Error:', error);
    res.status(500).json({ error: error.message || 'Internal Server Error' });
  }
});

// Proxy endpoint for Image Generation
app.post('/api/generate-image', async (req, res) => {
  try {
    const { prompt } = req.body;
    
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: prompt }],
      },
    });

    let imageUrl = '';
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        imageUrl = `data:image/png;base64,${part.inlineData.data}`;
        break;
      }
    }

    if (!imageUrl) {
      return res.status(500).json({ error: 'No image generated' });
    }

    res.json({ imageUrl });
  } catch (error: any) {
    console.error('Image Generation Error:', error);
    res.status(500).json({ error: error.message || 'Internal Server Error' });
  }
});

// Proxy endpoint for Voice Studio Variant Generation (Now powered by Groq)
app.post('/api/generate-variants', async (req, res) => {
  try {
    const { idea, tone, platform, userSamples } = req.body;
    
    if (!idea) {
      return res.status(400).json({ error: 'Idea is required' });
    }

    const completion = await groq.chat.completions.create({
      model: "llama-3.3-70b-versatile",
      messages: [
        { 
          role: "system", 
          content: `You are a world-class personal branding expert and social media ghostwriter.
          Your goal is to transform ideas into viral-ready posts that sound authentic to the user's voice.
          Always return ONLY a JSON array of 3 strings. Each string is a post variant.
          
          User Writing Samples for Voice Matching:
          ${userSamples || "No samples provided. Use a professional and engaging tone."}`
        },
        { 
          role: "user", 
          content: `Transform this idea into 3 distinct social media posts for ${platform}.
          Idea: "${idea}"
          Tone: ${tone}
          
          Format: JSON array of strings.` 
        }
      ],
      response_format: { type: "json_object" },
    });

    const responseContent = completion.choices[0].message.content || "[]";
    const parsed = JSON.parse(responseContent);
    
    // Support both { "variants": [...] } and direct [...] if the model fluctuates
    const variants = Array.isArray(parsed) ? parsed : (parsed.variants || parsed.posts || []);
    
    res.json({ variants });
  } catch (error: any) {
    console.error('Groq Variant Generation Error:', error);
    res.status(500).json({ error: error.message || 'Internal Server Error' });
  }
});

// Proxy endpoint for BrandScore analysis
app.post('/api/generate-brand-score', async (req, res) => {
  try {
    const { posts } = req.body;
    
    const completion = await groq.chat.completions.create({
      model: "llama-3.3-70b-versatile",
      messages: [
        { 
          role: "system", 
          content: "You are a personal brand strategist. Analyze the provided social media posts and return a JSON object with scores (0-100) and insights. Format: { overallScore, consistency, hookStrength, engagementPotential, insight }"
        },
        { 
          role: "user", 
          content: `Analyze these posts: ${JSON.stringify(posts)}` 
        }
      ],
      response_format: { type: "json_object" },
    });

    res.json(JSON.parse(completion.choices[0].message.content || "{}"));
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Proxy endpoint for PersonaKit generation
app.post('/api/generate-persona-kit', async (req, res) => {
  try {
    const { answers } = req.body;
    
    const completion = await groq.chat.completions.create({
      model: "llama-3.3-70b-versatile",
      messages: [
        { 
          role: "system", 
          content: "You are a brand identity expert. Create a persona kit based on the quiz answers. Return ONLY JSON. Format: { niche, positioning, toneOfVoice, contentPillars: [], targetAudience, bioVariants: { linkedin, instagram, twitter }, postTopics: [] }"
        },
        { 
          role: "user", 
          content: `Quiz Answers: ${JSON.stringify(answers)}` 
        }
      ],
      response_format: { type: "json_object" },
    });

    res.json(JSON.parse(completion.choices[0].message.content || "{}"));
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Handle React routing, return all requests to React app
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

app.listen(port, '0.0.0.0', () => {
  console.log(`Server listening on port ${port}`);
});
