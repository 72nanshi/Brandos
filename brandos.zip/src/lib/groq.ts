export async function generateBrandPost(
  userSamples: string,
  idea: string,
  tone: string,
  platform: string
) {
  const resp = await fetch('/api/generate-variants', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userSamples, idea, tone, platform })
  });
  
  if (!resp.ok) {
    const err = await resp.json();
    throw new Error(err.error || 'Failed to generate variants');
  }
  
  const data = await resp.json();
  return data.variants;
}

export async function generateBrandScore(posts: string[]) {
  const resp = await fetch('/api/generate-brand-score', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ posts })
  });
  if (!resp.ok) throw new Error('Failed to analyze score');
  return await resp.json();
}

export async function generatePersonaKit(answers: object) {
  const resp = await fetch('/api/generate-persona-kit', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ answers })
  });
  if (!resp.ok) throw new Error('Failed to generate persona kit');
  return await resp.json();
}
